# azure_ad_web

#Run this command
pip install .